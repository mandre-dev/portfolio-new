import type { Metadata, Viewport } from 'next'
import './globals.css'

export const metadata: Metadata = {
  title: 'Marcos André — Fullstack Dev & DevOps',
  description:
    'Desenvolvedor Full-Stack & DevOps especialista em Next.js, Node.js, Docker e CI/CD. Cabo Frio, RJ.',
  keywords: [
    'Fullstack Developer',
    'DevOps Engineer',
    'Next.js',
    'Node.js',
    'Docker',
    'React',
    'TypeScript',
    'Cabo Frio',
    'Brasil',
  ],
  authors: [{ name: 'Marcos André' }],
  openGraph: {
    title: 'Marcos André — Fullstack Dev & DevOps',
    description: 'Desenvolvedor Full-Stack & DevOps. Next.js, Node.js, Docker, CI/CD.',
    type: 'website',
    locale: 'pt_BR',
  },
  robots: {
    index: true,
    follow: true,
  },
}

export const viewport: Viewport = {
  themeColor: [
    { media: '(prefers-color-scheme: light)', color: '#f8f9fc' },
    { media: '(prefers-color-scheme: dark)', color: '#0d0f14' },
  ],
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="pt-BR" suppressHydrationWarning>
      <body>{children}</body>
    </html>
  )
}
